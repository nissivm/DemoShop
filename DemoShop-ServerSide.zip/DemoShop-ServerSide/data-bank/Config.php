<?php

define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_HOST', 'localhost');
define('DB_NAME', 'shop_manager');
 
define('USER_SUCCESSFULLY_CREATED', 'user successfully created');
define('USER_CREATION_FAILED', 'user creation failed');
define('NONEXISTENT_USER', 'nonexistent user');
define('USERNAME_TAKEN', 'username taken');
define('USERNAME_FREE', 'username free');
define('PASSWORD_CORRECT', 'password correct');
define('PASSWORD_INCORRECT', 'password incorrect');
define('ERROR_RETRIEVING_USER', 'error retrieving user');

define('ORDER_SUCCESSFULLY_CREATED', 'order successfully created');
define('ORDER_CREATION_FAILED', 'order creation failed');

define('SELECT_QUERY_ERROR', 'select query error');

?>