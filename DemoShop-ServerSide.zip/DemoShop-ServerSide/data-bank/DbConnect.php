<?php

require __DIR__  . '/Config.php';

class DbConnect {
 
    private $conn;
 
    function __construct() {        
    }
 
    /**
     * Establishing database connection
     * @return database connection handler
     */
    function connect() {
        
        // Open a new connection to mysql database
        $this->conn = new mysqli(DB_HOST, DB_USERNAME, DB_PASSWORD, DB_NAME);
		
		// Check connection
		// connect_error -> Returns a string description of the last connect error
		if ($this->conn->connect_error) 
		{
    		echo "Failed to connect to MySQL: " . $conn->connect_error;
			return NULL;
		}
 
        return $this->conn;
    }
 
}

?>