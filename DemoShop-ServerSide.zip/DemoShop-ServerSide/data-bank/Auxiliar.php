<?php

class Auxiliar {
 
    function __construct() {  
		      
    }
	
	/* ------------- Email validation ------------------ */
	
	/**
     * Verify if email has @
	 *
	 * @param String $email user email
	 * @return Boolean
     */
	public function invalidEmail($email) {
		
		if(stristr($email,"@") == false)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	/* ------------- Date/Time now ------------------ */
	
	public function getDateAndTimeNow()
	{
		date_default_timezone_set("America/Fortaleza");
		return date("Y.m.d") . ' / ' . date("h:i:sa");
	}
	
	/* ------------- Error report ------------------ */
	
	/**
     * Sends an email to report select query failure
	 *
	 * @param String $bodyMessage body message with the failure details
	 * @return Void
     */
	public function reportSelectQueryFailure($bodyMessage)
	{
		$msg = wordwrap($bodyMessage, 50);
		mail("nissivm@yahoo.com.br", "Select query failure", $msg);
	}
	
	/**
     * Sends an email to report insert into query failure
	 *
	 * @param String $bodyMessage body message with the failure details
	 * @return Void
     */
	public function reportInsertIntoQueryFailure($bodyMessage)
	{
		$msg = wordwrap($bodyMessage, 50);
		mail("nissivm@yahoo.com.br", "Insert into query failure", $msg);
	}
	
	/**
     * Sends an email to report order creation failure
	 *
	 * @param String $bodyMessage body message with all necessary data to manually create the order
	 * @return Void
     */
	public function reportOrderCreationFailure($bodyMessage)
	{
		$msg = wordwrap($bodyMessage, 50);
		mail("nissivm@yahoo.com.br", "Order creation failure", $msg);
	}
}

?>