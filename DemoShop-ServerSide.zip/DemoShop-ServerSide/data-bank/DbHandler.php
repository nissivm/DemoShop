<?php

require __DIR__  . '/DbConnect.php';
require __DIR__  . '/Auxiliar.php';

class DbHandler {
 
    private $conn;
	public $auxiliar;
 
    function __construct() {
        
        $db = new DbConnect(); // opening db connection
        $this->conn = $db->connect(); // returns mysqli object
		$this->auxiliar = new Auxiliar();
    }
 
    /* ------------- `users` table ------------------ */
  
	/**
     * Creates a new record in users table
	 *
     * @param String $name user name
	 * @param String $username user username
	 * @param String $password user password
	 * @param String $email user email
	 * @return String
     */
    public function createUser($name, $username, $password, $email) {
        
		// prepare -> Returns a mysqli_stmt object
		// bind_param -> Binds variables to a prepared statement as parameters
		
		$stmt = $this->conn->prepare("INSERT INTO users(name, username, password, email) values(?, ?, ?, ?)");
        
		if ($stmt)
		{
			$password_hash = password_hash($password, PASSWORD_DEFAULT);
			$stmt->bind_param("ssss", $name, $username, $password_hash, $email);
			
			if ($stmt->execute())
			{
				$stmt->close();
				return USER_SUCCESSFULLY_CREATED;
			}
			else
			{
				return USER_CREATION_FAILED;
			}
		}
		else
		{
			return USER_CREATION_FAILED;
		}
    }
  
	/**
     * User sign in
	 *
	 * @param String $username user username
	 * @param String $password user password
	 * @return String
     */
    public function userSignIn($username, $password) {
        
		$stmt = $this->conn->prepare("SELECT password FROM users WHERE username = ?");
		
        if ($stmt)
		{
			$stmt->bind_param("s", $username);
			
			if ($stmt->execute())
			{
				$stmt->bind_result($password_hash); // bind_result -> Sets the variable that will receive the buffered resul
        		$stmt->store_result(); // store_result -> Buffers the result
		
				if ($stmt->num_rows == 0)
				{
					$stmt->close();
            		return NONEXISTENT_USER;
				}
 
        		$stmt->fetch(); // fetch -> Stores the buffered result into $password_hash
        		$stmt->close();
 
        		if (password_verify($password, $password_hash)) 
				{
        			return PASSWORD_CORRECT;
        		} 
				else 
				{
        			return PASSWORD_INCORRECT;
        		}
			}
			else
			{
				return SELECT_QUERY_ERROR;
			}
		}
		else
		{
			return SELECT_QUERY_ERROR;
		}
    }
	
	/**
     * Fetches a single user by username
	 *
	 * @param String $username user username
	 * @return The user, as an associative array, or a String representing an error
     */
    public function getUserByUsername($username) {
		
		$stmt = $this->conn->prepare("SELECT * FROM users WHERE username = ?");
		
        if ($stmt)
		{
			$stmt->bind_param("s", $username);
			
			if ($stmt->execute())
			{
				$user = $stmt->get_result()->fetch_assoc(); // fetch_assoc -> Fetch a result row as an associative array (key/value)
        		$stmt->close();
        		return $user;
			}
			else
			{
				return ERROR_RETRIEVING_USER;
			}
		}
		else
		{
			return ERROR_RETRIEVING_USER;
		}
    }
	
	/**
     * Verify if username is taken
	 *
	 * @param String $username user username
	 * @return String
     */
    public function usernameTaken($username) {
		
		$stmt = $this->conn->prepare("SELECT * FROM users WHERE username = ?");
		
		if ($stmt)
		{
			$stmt->bind_param("s", $username);
		
			if ($stmt->execute())
			{
				$stmt->store_result();
        		$num_rows = $stmt->num_rows;
        		$stmt->close();
				
				if ($num_rows > 0)
				{
					return USERNAME_TAKEN;
				}
				else
				{
					return USERNAME_FREE;
				}
			}
			else
			{
				return SELECT_QUERY_ERROR;
			}
		}
		else
		{
			return SELECT_QUERY_ERROR;
		}
    }
 
    /* ------------- `items_for_sale` table ------------------ */
 
    /**
     * Fetches a number of 6 items for sale starting on a given point
	 *
     * @param Integer $offset the point where to start retrieving
	 * @return A collection of associative arrays, each one representing one item for sale.
	 *		   May return NULL in case SELECT returns no records.
	 *		   May return a String representing an error.
     */
    public function fetchItemsForSale($offset) {
		
        $stmt = $this->conn->prepare("SELECT * FROM items_for_sale ORDER BY id LIMIT 6 OFFSET ?");
		
		if ($stmt)
		{
			$off = $offset - 1;
			$stmt->bind_param("i", $off);
			
			if ($stmt->execute())
			{
				$res = $stmt->get_result();
				
				if ($res->num_rows > 0) // Has results to return
				{
					while ($row = $res->fetch_assoc()) 
					{
        				$items[] = $row;
    				}
					
        			$stmt->close();
        			return $items;
				}
				else
				{
					$stmt->close();
            		return NULL;
				}
			}
			else
			{
				return SELECT_QUERY_ERROR;
			}
		}
		else
		{
			return SELECT_QUERY_ERROR;
		}
    }
 
    /* ------------- `orders` table ------------------ */
 
    /**
     * Creates a new record in orders table
	 *
     * @param String $chargeId id of the charge created in Stripe
     * @param String $clientId primary key id of the user who made the purchase
	 * @param String $description list of purchase items
     * @param String $chargeAmount purchase total value
	 * @return String
     */
    public function createOrder($chargeId, $clientId, $description, $chargeAmount) {
		
        $stmt = $this->conn->prepare("INSERT INTO orders(chargeId, clientId, description, charge_amount) values(?, ?, ?, ?)");
		
		if ($stmt)
		{
			$stmt->bind_param("sssd", $chargeId, $clientId, $description, $chargeAmount);
			
			if ($stmt->execute())
			{
				$stmt->close();
				return ORDER_SUCCESSFULLY_CREATED;
			}
			else 
			{
            	return ORDER_CREATION_FAILED;
        	}
		}
		else 
		{
            return ORDER_CREATION_FAILED;
        }
    }
}
 
?>