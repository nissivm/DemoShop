<?php

require __DIR__  . '/data-bank/DbHandler.php';

// read JSon input:
$handle = fopen('php://input','r'); // Open file for reading only
$jSon = fgets($handle); // Reads the file and stores it in the variable as a jSon string
$data = json_decode($jSon, true); // Takes the jSon string and turns it in an associative array (the "true" parameter)

// Get JSon content:
$name = $data["name"];
$username = $data["username"];
$password = $data["password"];
$email = $data["email"];

$dbHandler = new DbHandler();
$res = $dbHandler->createUser($name, $username, $password, $email);

if ($res == USER_CREATION_FAILED)
{
	$bodyMessage = 'Error while performing an insert into query in users table. Time of error => '.$dbHandler->auxiliar->getDateAndTimeNow();
	$dbHandler->auxiliar->reportInsertIntoQueryFailure($bodyMessage);
	
	$responseFour = array('status' => 'Error');
	echo json_encode($responseFour);
	exit(0);
}

$responseFour = array('status' => 'Success');
echo json_encode($responseFour);

?>