<?php

require __DIR__  . '/vendor/autoload.php';
require __DIR__  . '/data-bank/DbHandler.php';

$app = new Slim\App();

/**
* Take the request to verify user registration data
*
* URL: http://localhost/DemoShop-ServerSide/verifyUserRegistrationData/email/username
*/
$app->get('/verifyUserRegistrationData/{email}/{username}', function($request, $response, $args) {
	
	$email = $args['email'];
	$username = $args['username'];
	
	$dbHandler = new DbHandler();
	
	if ($dbHandler->auxiliar->invalidEmail($email))
	{
		$response = array('status' => 'Invalid email', 'message' => 'This email is invalid.');
		echo json_encode($response);
		exit(0);
	}
	
	$res = $dbHandler->usernameTaken($username);
	
	if ($res == SELECT_QUERY_ERROR)
	{
		$bodyMessage = 'Error while performing a select query in users table. Time of error => '.$dbHandler->auxiliar->getDateAndTimeNow();
		$dbHandler->auxiliar->reportSelectQueryFailure($bodyMessage);
		
		$response = array('status' => 'Registration error', 'message' => 'Error while registering.');
		echo json_encode($response);
		exit(0);
	}
	
	if ($res == USERNAME_TAKEN)
	{
		$response = array('status' => 'Username taken', 'message' => 'This username is already being used.');
		echo json_encode($response);
		exit(0);
	}
	
	$response = array('status' => 'Success');
	echo json_encode($response);
});

/**
* Take the request to retrieve an user by his/her username
*
* URL: http://localhost/DemoShop-ServerSide/retrieveUserByUsername/username
*/
$app->get('/retrieveUserByUsername/{username}', function($request, $response, $args) {
	
	$username = $args['username'];
	
	$dbHandler = new DbHandler();
	$res = $dbHandler->getUserByUsername($username);

	if ($res == ERROR_RETRIEVING_USER)
	{
		$bodyMessage = 'Error while performing a select query in users table. Time of error => '.$dbHandler->auxiliar->getDateAndTimeNow();
		$dbHandler->auxiliar->reportSelectQueryFailure($bodyMessage);
		
		$response = array('status' => 'Error');
		echo json_encode($response);
		exit(0);
	}

	$res["sessionStatus"] = 'valid';
	$res["sessionStart"] = time();

	$response = array();
	$response['status'] = 'Success';
	$response['user'] = $res;

	echo json_encode($response);
});

/**
* Take the request to sign in a registered user
*
* URL: http://localhost/DemoShop-ServerSide/userSignIn/username/password
*/
$app->get('/userSignIn/{username}/{password}', function($request, $response, $args) {
	
	$username = $args['username'];
	$password = $args['password'];
	
	$dbHandler = new DbHandler();
	$res = $dbHandler->userSignIn($username, $password);
	
	if ($res == SELECT_QUERY_ERROR)
	{
		$bodyMessage = 'Error while performing a select query in users table. Time of error => '.$dbHandler->auxiliar->getDateAndTimeNow();
		$dbHandler->auxiliar->reportSelectQueryFailure($bodyMessage);
		
		$response = array('status' => 'Sign in error', 'message' => 'Error while signing in.');
		echo json_encode($response);
		exit(0);
	}
	
	if ($res == NONEXISTENT_USER)
	{
		$response = array('status' => 'Unregistered user', 'message' => 'User does not exist.');
		echo json_encode($response);
		exit(0);
	}
	
	if ($res == PASSWORD_INCORRECT)
	{
		$response = array('status' => 'Incorrect password', 'message' => 'The password is incorrect.');
		echo json_encode($response);
		exit(0);
	}
	
	$response = array('status' => 'Success');
	echo json_encode($response);
});

/**
* Take the request to retrieve the items for sale
*
* URL: http://localhost/DemoShop-ServerSide/fetchItemsForSale/offset
*/
$app->get('/fetchItemsForSale/{offset}', function($request, $response, $args) {
	
	$offset = (integer) $args['offset'];
	
	$dbHandler = new DbHandler();
    $res = $dbHandler->fetchItemsForSale($offset);
	
	if ($res == SELECT_QUERY_ERROR)
	{
		$bodyMessage = 'Error while performing a select query in items for sale table. Time of error => '.$dbHandler->auxiliar->getDateAndTimeNow();
		$dbHandler->auxiliar->reportSelectQueryFailure($bodyMessage);
		
		$response = array('status' => 'Error');
		echo json_encode($response);
		exit(0);
	}
	
	if ($res == NULL)
	{
		$response = array('status' => 'No results');
		echo json_encode($response);
		exit(0);
	}
	
	$response = array();
	$response['status'] = "Success";
	$response['items'] = $res;
	echo json_encode($response);
});

$app->run();

?>