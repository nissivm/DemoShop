<?php

require __DIR__  . '/vendor/autoload.php';
require __DIR__  . '/data-bank/DbHandler.php';

// Set your secret key: remember to change this to your live secret key in production
// See your keys here https://dashboard.stripe.com/account/apikeys
\Stripe\Stripe::setApiKey("YOUR TEST SECRET KEY");

// read JSon input
$handle = fopen('php://input','r'); // Open file for reading only
$jSon = fgets($handle); // Reads the file and stores it in the variable as a jSon string
$data = json_decode($jSon, true); // Takes the jSon string and turns it in an associative array (the "true" parameter)
 
// Get JSon content:
$token = $data["stripeToken"];
$clientId = $data["clientId"];
$clientEmail = $data["clientEmail"];
$amount = $data["amount"];
$currency = $data["currency"];
$description = $data["description"];

// Create the charge on Stripe's servers - this will charge the user's card
try 
{
	$charge = \Stripe\Charge::create(array(
  	"amount" => (integer) $amount * 100, // Otherwise, a purchase of $190,00 will be charged as $1,90
  	"currency" => $currency,
  	"source" => $token,
  	"description" => $description,
	"receipt_email" => $clientEmail)
	);

	if ($charge->paid) // Charge succeeded
	{
		$chargeId = $charge['id'];
		$chargeAmount = (float) $amount;
		$dbHandler = new DbHandler();
    	$res = $dbHandler->createOrder($chargeId, $clientId, $description, $chargeAmount); // Create client's order
		
		if ($res != ORDER_SUCCESSFULLY_CREATED) // Error creating order
		{
			$bodyMessage = 'Error while creating this order:' . 
							' Charge ID = ' . $chargeId . 
						   ', Client ID = ' . $clientId . 
						   ', Description = ' . $description .
						   ', Charge amount = ' . $chargeAmount .
						   ', Time of error => '.$dbHandler->auxiliar->getDateAndTimeNow();
						   
			$dbHandler->auxiliar->reportOrderCreationFailure($bodyMessage);
		}
		
		$response = array('status'=>'Success','message'=>'Purchase successfully made!');
	} 
	else // Charge was not paid!
	{ 
		$response = array('status'=>'Payment error','message'=>'The payment system rejected the transaction. Please try again or use another card.');
	}

	echo json_encode($response);
} 
catch(\Stripe\Error\Card $e) 
{
  	// The card has been declined
	$response = array( 'status'=> 'Payment error', 'message'=>'Your card has been declined. Please try again using another card.' );
	echo json_encode($response);
}

?>